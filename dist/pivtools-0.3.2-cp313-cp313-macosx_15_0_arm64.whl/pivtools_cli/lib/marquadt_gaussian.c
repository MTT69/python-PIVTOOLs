// marquadt_gaussian.c
// Optimized Stacked Gaussian fitting using Levenberg-Marquardt via GSL

#define _POSIX_C_SOURCE 200112L
#include <math.h>
#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>

#include <gsl/gsl_vector.h>
#include <gsl/gsl_matrix.h>
#include <gsl/gsl_multifit_nlinear.h>
#include <gsl/gsl_blas.h>
#include <gsl/gsl_errno.h>

#ifdef _OPENMP
#include <omp.h>
#endif

#if defined(_WIN32) || defined(__WIN32__)
  #define PIV_EXPORT __declspec(dllexport)
#elif defined(__GNUC__)
  #define PIV_EXPORT __attribute__((visibility("default")))
#else
  #define PIV_EXPORT
#endif

#define P_PARAMS 16
#define TARGET_GRID_DIM 32      // Downsample to ~32x32 = 1024 pts (good balance)
#define SIGMA_MIN 1e-6          // Minimum variance to prevent singular matrices
#define FIT_TOL 1e-4            // Convergence tolerance (1e-4 is good for PIV)
#define MAX_ITER 20             // Max LM iterations (20 usually converges or never will)

// Global flag to disable offset (+C) fitting for testing
// 0 = fit offsets normally, 1 = fix offsets to zero
static int g_disable_offset = 0;

// Export function to toggle offset fitting mode
PIV_EXPORT void set_disable_offset(int disable) {
    g_disable_offset = disable;
}

struct fit_data {
    size_t n;
    const double *X1;
    const double *X2;
    const double *y;
};

struct cholesky_derivs {
    double dL00_dsx, dL10_dsx, dL11_dsx;
    double dL00_dsy, dL10_dsy, dL11_dsy;
    double dL00_dsxy, dL10_dsxy, dL11_dsxy;
};

static void calc_sigma_derivs(double sx, double sy, double sxy,
                              double L00, double L10, double L11,
                              struct cholesky_derivs *d) {
    double inv_sx = 1.0 / sx;
    double term = sxy * inv_sx;
    double dL11_dR = -0.5 * L11 * L11 * L11;

    d->dL00_dsx = -0.5 * L00 * inv_sx;
    d->dL11_dsx = dL11_dR * (term * term);
    d->dL10_dsx = -((-term * inv_sx) * L11 + term * d->dL11_dsx);

    d->dL00_dsy = 0.0;
    d->dL11_dsy = dL11_dR;
    d->dL10_dsy = -term * d->dL11_dsy;

    d->dL00_dsxy = 0.0;
    d->dL11_dsxy = dL11_dR * (-2.0 * term);
    d->dL10_dsxy = -(inv_sx * L11 + term * d->dL11_dsxy);
}

static inline double clamp_sigma(double s) {
    return (s < SIGMA_MIN) ? SIGMA_MIN : s;
}

static inline double safe_sqrt_rad(double rad) {
    return (rad > 0.0) ? sqrt(rad) : SIGMA_MIN;
}

static int gauss2d_f(const gsl_vector *x, void *data, gsl_vector *f) {
    struct fit_data *d = (struct fit_data *)data;
    const size_t n = d->n;
    const double *X1 = d->X1;
    const double *X2 = d->X2;
    const double *y = d->y;

    double amp_A  = fmax(gsl_vector_get(x, 0), 0.0);
    double amp_B  = fmax(gsl_vector_get(x, 1), 0.0);
    double amp_AB = fmax(gsl_vector_get(x, 2), 0.0);
    // When g_disable_offset is set, fix offsets to zero (don't read from params)
    double c_A    = g_disable_offset ? 0.0 : gsl_vector_get(x, 3);
    double c_B    = g_disable_offset ? 0.0 : gsl_vector_get(x, 4);
    double c_AB   = g_disable_offset ? 0.0 : gsl_vector_get(x, 5);
    double sx_A   = clamp_sigma(gsl_vector_get(x, 6));
    double sy_A   = clamp_sigma(gsl_vector_get(x, 7));
    double sxy_A  = gsl_vector_get(x, 8);
    double sx_AB  = clamp_sigma(gsl_vector_get(x, 9));
    double sy_AB  = clamp_sigma(gsl_vector_get(x, 10));
    double sxy_AB = gsl_vector_get(x, 11);
    double x0_A   = gsl_vector_get(x, 12);
    double y0_A   = gsl_vector_get(x, 13);
    double x0_AB  = gsl_vector_get(x, 14);
    double y0_AB  = gsl_vector_get(x, 15);

    double sqrt_sx_A = sqrt(sx_A);
    double term_A = sxy_A / sqrt_sx_A;
    double LA_11 = safe_sqrt_rad(sy_A - term_A * term_A);
    double inv_LA_00 = 1.0 / sqrt_sx_A;
    double inv_LA_11 = 1.0 / LA_11;
    double inv_LA_10 = -term_A * inv_LA_00 * inv_LA_11;

    double sum_sx = sx_A + sx_AB;
    double sum_sxy = sxy_A + sxy_AB;
    double sum_sy = sy_A + sy_AB;
    double sqrt_sum_sx = sqrt(sum_sx);
    double term_AB = sum_sxy / sqrt_sum_sx;
    double LAB_11 = safe_sqrt_rad(sum_sy - term_AB * term_AB);
    double inv_LAB_00 = 1.0 / sqrt_sum_sx;
    double inv_LAB_11 = 1.0 / LAB_11;
    double inv_LAB_10 = -term_AB * inv_LAB_00 * inv_LAB_11;

    for (size_t i = 0; i < n; i++) {
        double dx_A = X1[i] - x0_A;
        double dy_A = X2[i] - y0_A;
        double tA_0 = inv_LA_00 * dx_A;
        double tA_1 = inv_LA_10 * dx_A + inv_LA_11 * dy_A;
        double exp_A = exp(-0.5 * (tA_0 * tA_0 + tA_1 * tA_1));

        double dx_AB = X1[i] - x0_AB;
        double dy_AB = X2[i] - y0_AB;
        double tAB_0 = inv_LAB_00 * dx_AB;
        double tAB_1 = inv_LAB_10 * dx_AB + inv_LAB_11 * dy_AB;
        double exp_AB = exp(-0.5 * (tAB_0 * tAB_0 + tAB_1 * tAB_1));

        gsl_vector_set(f, i,         amp_A  * exp_A  + c_A  - y[i]);
        gsl_vector_set(f, i + n,     amp_B  * exp_A  + c_B  - y[i + n]);
        gsl_vector_set(f, i + 2*n,   amp_AB * exp_AB + c_AB - y[i + 2*n]);
    }
    return GSL_SUCCESS;
}

static int gauss2d_df(const gsl_vector *x, void *data, gsl_matrix *J) {
    struct fit_data *d = (struct fit_data *)data;
    const size_t n = d->n;
    const double *X1 = d->X1;
    const double *X2 = d->X2;

    double amp_A  = gsl_vector_get(x, 0);
    double amp_B  = gsl_vector_get(x, 1);
    double amp_AB = gsl_vector_get(x, 2);
    double sx_A   = clamp_sigma(gsl_vector_get(x, 6));
    double sy_A   = clamp_sigma(gsl_vector_get(x, 7));
    double sxy_A  = gsl_vector_get(x, 8);
    double sx_AB  = clamp_sigma(gsl_vector_get(x, 9));
    double sy_AB  = clamp_sigma(gsl_vector_get(x, 10));
    double sxy_AB = gsl_vector_get(x, 11);
    double x0_A   = gsl_vector_get(x, 12);
    double y0_A   = gsl_vector_get(x, 13);
    double x0_AB  = gsl_vector_get(x, 14);
    double y0_AB  = gsl_vector_get(x, 15);

    double sqrt_sx_A = sqrt(sx_A);
    double term_A = sxy_A / sqrt_sx_A;
    double LA_11 = safe_sqrt_rad(sy_A - term_A * term_A);
    double inv_LA_00 = 1.0 / sqrt_sx_A;
    double inv_LA_11 = 1.0 / LA_11;
    double inv_LA_10 = -term_A * inv_LA_00 * inv_LA_11;

    struct cholesky_derivs dA;
    calc_sigma_derivs(sx_A, sy_A, sxy_A, inv_LA_00, inv_LA_10, inv_LA_11, &dA);

    double sum_sx = sx_A + sx_AB;
    double sum_sxy = sxy_A + sxy_AB;
    double sum_sy = sy_A + sy_AB;
    double sqrt_sum_sx = sqrt(sum_sx);
    double term_AB = sum_sxy / sqrt_sum_sx;
    double LAB_11 = safe_sqrt_rad(sum_sy - term_AB * term_AB);
    double inv_LAB_00 = 1.0 / sqrt_sum_sx;
    double inv_LAB_11 = 1.0 / LAB_11;
    double inv_LAB_10 = -term_AB * inv_LAB_00 * inv_LAB_11;

    struct cholesky_derivs dAB;
    calc_sigma_derivs(sum_sx, sum_sy, sum_sxy, inv_LAB_00, inv_LAB_10, inv_LAB_11, &dAB);

    gsl_matrix_set_zero(J);

    for (size_t i = 0; i < n; i++) {
        double dx = X1[i] - x0_A;
        double dy = X2[i] - y0_A;
        double t0 = inv_LA_00 * dx;
        double t1 = inv_LA_10 * dx + inv_LA_11 * dy;
        double exp_A = exp(-0.5 * (t0*t0 + t1*t1));

        gsl_matrix_set(J, i, 0, exp_A);
        gsl_matrix_set(J, i + n, 1, exp_A);
        // Skip offset Jacobians if disabled (offsets fixed to zero)
        if (!g_disable_offset) {
            gsl_matrix_set(J, i, 3, 1.0);      // d/d(c_A)
            gsl_matrix_set(J, i + n, 4, 1.0);  // d/d(c_B)
        }

        double fact_A = -amp_A * exp_A;
        double fact_B = -amp_B * exp_A;

        double dQ_dx0 = t0 * (-inv_LA_00) + t1 * (-inv_LA_10);
        double dQ_dy0 = t1 * (-inv_LA_11);
        gsl_matrix_set(J, i, 12, fact_A * dQ_dx0);
        gsl_matrix_set(J, i, 13, fact_A * dQ_dy0);
        gsl_matrix_set(J, i + n, 12, fact_B * dQ_dx0);
        gsl_matrix_set(J, i + n, 13, fact_B * dQ_dy0);

        double val_dsx = t0 * (dx * dA.dL00_dsx) + t1 * (dx * dA.dL10_dsx + dy * dA.dL11_dsx);
        double val_dsy = t1 * (dx * dA.dL10_dsy + dy * dA.dL11_dsy);
        double val_dsxy = t1 * (dx * dA.dL10_dsxy + dy * dA.dL11_dsxy);
        gsl_matrix_set(J, i, 6, fact_A * val_dsx);
        gsl_matrix_set(J, i + n, 6, fact_B * val_dsx);
        gsl_matrix_set(J, i, 7, fact_A * val_dsy);
        gsl_matrix_set(J, i + n, 7, fact_B * val_dsy);
        gsl_matrix_set(J, i, 8, fact_A * val_dsxy);
        gsl_matrix_set(J, i + n, 8, fact_B * val_dsxy);

        size_t row_ab = i + 2 * n;
        double dx_ab = X1[i] - x0_AB;
        double dy_ab = X2[i] - y0_AB;
        double t0_ab = inv_LAB_00 * dx_ab;
        double t1_ab = inv_LAB_10 * dx_ab + inv_LAB_11 * dy_ab;
        double exp_AB = exp(-0.5 * (t0_ab*t0_ab + t1_ab*t1_ab));

        gsl_matrix_set(J, row_ab, 2, exp_AB);
        // Skip offset Jacobian for AB if disabled
        if (!g_disable_offset) {
            gsl_matrix_set(J, row_ab, 5, 1.0);  // d/d(c_AB)
        }

        double fact_AB = -amp_AB * exp_AB;

        double dQ_dx0_ab = t0_ab * (-inv_LAB_00) + t1_ab * (-inv_LAB_10);
        double dQ_dy0_ab = t1_ab * (-inv_LAB_11);
        gsl_matrix_set(J, row_ab, 14, fact_AB * dQ_dx0_ab);
        gsl_matrix_set(J, row_ab, 15, fact_AB * dQ_dy0_ab);

        double val_dsx_ab = t0_ab * (dx_ab * dAB.dL00_dsx) + t1_ab * (dx_ab * dAB.dL10_dsx + dy_ab * dAB.dL11_dsx);
        double val_dsy_ab = t1_ab * (dx_ab * dAB.dL10_dsy + dy_ab * dAB.dL11_dsy);
        double val_dsxy_ab = t1_ab * (dx_ab * dAB.dL10_dsxy + dy_ab * dAB.dL11_dsxy);

        gsl_matrix_set(J, row_ab, 9, fact_AB * val_dsx_ab);
        gsl_matrix_set(J, row_ab, 10, fact_AB * val_dsy_ab);
        gsl_matrix_set(J, row_ab, 11, fact_AB * val_dsxy_ab);
        gsl_matrix_set(J, row_ab, 6, fact_AB * val_dsx_ab);
        gsl_matrix_set(J, row_ab, 7, fact_AB * val_dsy_ab);
        gsl_matrix_set(J, row_ab, 8, fact_AB * val_dsxy_ab);
    }
    return GSL_SUCCESS;
}

// --- Single fit using pre-allocated workspace (NO allocation per call) ---
static int fit_one_reuse(
    gsl_multifit_nlinear_workspace *work,
    size_t n,
    const double *X1,
    const double *X2,
    const double *y,
    const double *guess,
    double *result
) {
    struct fit_data d;
    d.n  = n;
    d.X1 = X1;
    d.X2 = X2;
    d.y  = y;

    gsl_multifit_nlinear_fdf fdf;
    fdf.f      = gauss2d_f;
    fdf.df     = gauss2d_df;
    fdf.fvv    = NULL;
    fdf.n      = 3 * n;
    fdf.p      = P_PARAMS;
    fdf.params = &d;

    gsl_vector_view xv = gsl_vector_view_array((double *)guess, P_PARAMS);
    gsl_multifit_nlinear_init(&xv.vector, &fdf, work);

    int info;
    int status = gsl_multifit_nlinear_driver(MAX_ITER, FIT_TOL, FIT_TOL, 0.0, NULL, NULL, &info, work);

    gsl_vector *x_out = gsl_multifit_nlinear_position(work);
    for (size_t i = 0; i < P_PARAMS; i++) {
        result[i] = gsl_vector_get(x_out, i);
    }

    // Clamp sigma values to ensure positive (unconstrained optimizer can go negative)
    // Indices: 6=sx_A, 7=sy_A, 9=sx_AB, 10=sy_AB
    result[6] = fmax(result[6], SIGMA_MIN);
    result[7] = fmax(result[7], SIGMA_MIN);
    result[9] = fmax(result[9], SIGMA_MIN);
    result[10] = fmax(result[10], SIGMA_MIN);

    return (status == GSL_SUCCESS || status == GSL_EMAXITER);
}

// --- Batch Export ---
PIV_EXPORT int fit_stacked_gaussian_batch_export(
    size_t num_windows,
    size_t n_per_window,
    const double *X1,
    const double *X2,
    const double *y_all,
    const double *initial_guesses,
    double *out_params,
    int *out_statuses
) {
    if (!X1 || !X2 || !y_all || !initial_guesses || !out_params || !out_statuses) {
        fprintf(stderr, "[fit] NULL pointer argument\n");
        return 0;
    }

    int success_count = 0;
    int win_w = (int)sqrt((double)n_per_window);

    int stride = (win_w > TARGET_GRID_DIM) ? (win_w / TARGET_GRID_DIM) : 1;
    int sub_w = (win_w + stride - 1) / stride;
    size_t n_sub = (size_t)(sub_w * sub_w);

    fprintf(stderr, "[fit] %zu windows, %dx%d -> stride %d -> %zu pts\n",
            num_windows, win_w, win_w, stride, n_sub);

    // Pre-compute downsampled coordinates
    double *sub_X1 = malloc(n_sub * sizeof(double));
    double *sub_X2 = malloc(n_sub * sizeof(double));
    size_t *src_idx = malloc(n_sub * sizeof(size_t));

    if (!sub_X1 || !sub_X2 || !src_idx) {
        fprintf(stderr, "[fit] malloc failed\n");
        free(sub_X1); free(sub_X2); free(src_idx);
        return 0;
    }

    size_t k = 0;
    for (int r = 0; r < win_w && k < n_sub; r += stride) {
        for (int c = 0; c < win_w && k < n_sub; c += stride) {
            size_t src = (size_t)(r * win_w + c);
            src_idx[k] = src;
            sub_X1[k] = X1[src];
            sub_X2[k] = X2[src];
            k++;
        }
    }
    size_t actual_n = k;

    fprintf(stderr, "[fit] actual subsampled points: %zu\n", actual_n);

    gsl_set_error_handler_off();

    // GSL workspace params (shared, read-only)
    const gsl_multifit_nlinear_type *T = gsl_multifit_nlinear_trust;
    gsl_multifit_nlinear_parameters fdf_params = gsl_multifit_nlinear_default_parameters();
    // Use more robust solver settings for production
    fdf_params.solver = gsl_multifit_nlinear_solver_cholesky;
    fdf_params.scale = gsl_multifit_nlinear_scale_more;

    #ifdef _OPENMP
    #pragma omp parallel reduction(+:success_count)
    {
    #endif
        // Thread-local Y buffer
        double *sub_y = malloc(3 * actual_n * sizeof(double));

        // Thread-local GSL workspace - allocated ONCE per thread, reused for all windows
        gsl_multifit_nlinear_workspace *work = gsl_multifit_nlinear_alloc(T, &fdf_params, 3 * actual_n, P_PARAMS);

        if (!sub_y || !work) {
            fprintf(stderr, "[fit] thread allocation failed\n");
        }

        #ifdef _OPENMP
        #pragma omp for schedule(dynamic, 16)
        #endif
        for (int i = 0; i < (int)num_windows; i++) {
            if (!sub_y || !work) {
                out_statuses[i] = 0;
                continue;
            }

            const double *y_win = y_all + (size_t)i * 3 * n_per_window;
            const double *guess = initial_guesses + (size_t)i * P_PARAMS;
            double *params = out_params + (size_t)i * P_PARAMS;

            // Downsample Y (cache-friendly sequential access)
            for (size_t j = 0; j < actual_n; j++) {
                size_t s = src_idx[j];
                sub_y[j]              = y_win[s];
                sub_y[j + actual_n]   = y_win[s + n_per_window];
                sub_y[j + 2*actual_n] = y_win[s + 2*n_per_window];
            }

            // Reuse workspace - no allocation!
            int ok = fit_one_reuse(work, actual_n, sub_X1, sub_X2, sub_y, guess, params);
            out_statuses[i] = ok;

            if (ok) {
                success_count++;
            } else {
                memcpy(params, guess, P_PARAMS * sizeof(double));
            }
        }

        // Free thread-local resources
        if (work) gsl_multifit_nlinear_free(work);
        free(sub_y);

    #ifdef _OPENMP
    }
    #endif

    free(sub_X1);
    free(sub_X2);
    free(src_idx);

    fprintf(stderr, "[fit] completed: %d/%zu succeeded\n", success_count, num_windows);

    return success_count;
}

PIV_EXPORT int fit_stacked_gaussian_export(
    size_t n,
    const double *X1,
    const double *X2,
    const double *y,
    const double *initial_guess,
    double *out_params,
    int *out_status
) {
    int status;
    int ret = fit_stacked_gaussian_batch_export(1, n, X1, X2, y, initial_guess, out_params, &status);
    if (out_status) *out_status = status ? 0 : -1;
    return ret;
}