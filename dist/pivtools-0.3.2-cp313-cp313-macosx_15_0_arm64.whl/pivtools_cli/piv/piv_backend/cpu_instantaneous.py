import ctypes
import logging
import os
import sys
import time
import traceback
import warnings
from pathlib import Path
from typing import List, Optional
import cv2
import dask.array as da
import numpy as np
from dask.distributed import get_worker
from scipy.ndimage import gaussian_filter
from scipy.signal import convolve2d


from pivtools_core.config import Config
from pivtools_core.window_utils import compute_window_centers
from pivtools_cli.piv.piv_backend.base import CrossCorrelator
from pivtools_cli.piv.piv_result import PIVPassResult, PIVResult
from pivtools_cli.piv.piv_backend.outlier_detection import apply_outlier_detection
from pivtools_cli.piv.piv_backend.infilling import apply_infilling


class InstantaneousCorrelatorCPU(CrossCorrelator):
    def __init__(self, config: Config, precomputed_cache: Optional[dict] = None) -> None:
        super().__init__()
        # Use platform-appropriate library extension
        lib_extension = ".dll" if os.name == "nt" else ".so"
        lib_path = os.path.join(
            os.path.dirname(__file__), "../..", "lib", f"libbulkxcorr2d{lib_extension}"
        )
        lib_path = os.path.abspath(lib_path)
        if not os.path.isfile(lib_path):
            raise FileNotFoundError(f"Required library file not found: {lib_path}")
        self.lib = ctypes.CDLL(lib_path)
        self.lib.bulkxcorr2d.restype = ctypes.c_ubyte
        self.delta_ab_pred = None
        self.delta_ab_old = None
        self.prev_win_size = None
        self.prev_win_spacing = None
        # Updated to use C-contiguous (row-major) arrays
        self.lib.bulkxcorr2d.argtypes = [
            np.ctypeslib.ndpointer(dtype=np.float32, flags="C_CONTIGUOUS"),  # fImageA
            np.ctypeslib.ndpointer(dtype=np.float32, flags="C_CONTIGUOUS"),  # fImageB
            np.ctypeslib.ndpointer(dtype=np.float32, flags="C_CONTIGUOUS"),  # fMask
            np.ctypeslib.ndpointer(dtype=np.int32, flags="C_CONTIGUOUS"),  # nImageSize
            np.ctypeslib.ndpointer(dtype=np.float32, flags="C_CONTIGUOUS"),  # fWinCtrsX
            np.ctypeslib.ndpointer(dtype=np.float32, flags="C_CONTIGUOUS"),  # fWinCtrsY
            np.ctypeslib.ndpointer(dtype=np.int32, flags="C_CONTIGUOUS"),  # nWindows
            np.ctypeslib.ndpointer(
                dtype=np.float32, flags="C_CONTIGUOUS"
            ),  # fWindowWeightA
            ctypes.c_bool,  # bEnsemble
            np.ctypeslib.ndpointer(
                dtype=np.float32, flags="C_CONTIGUOUS"
            ),  # fWindowWeightB
            np.ctypeslib.ndpointer(dtype=np.int32, flags="C_CONTIGUOUS"),  # nWindowSize
            ctypes.c_int,  # nPeaks
            ctypes.c_int,  # iPeakFinder
            np.ctypeslib.ndpointer(
                dtype=np.float32, flags="C_CONTIGUOUS"
            ),  # fPkLocX (output)
            np.ctypeslib.ndpointer(
                dtype=np.float32, flags="C_CONTIGUOUS"
            ),  # fPkLocY (output)
            np.ctypeslib.ndpointer(
                dtype=np.float32, flags="C_CONTIGUOUS"
            ),  # fPkHeight (output)
            np.ctypeslib.ndpointer(
                dtype=np.float32, flags="C_CONTIGUOUS"
            ),  # fSx (output)
            np.ctypeslib.ndpointer(
                dtype=np.float32, flags="C_CONTIGUOUS"
            ),  # fSy (output)
            np.ctypeslib.ndpointer(
                dtype=np.float32, flags="C_CONTIGUOUS"
            ),  # fSxy (output)
            np.ctypeslib.ndpointer(
                dtype=np.float32, flags="C_CONTIGUOUS"
            ),  # fCorrelPlane_Out (output)
        ]
        # Window weights should be C-contiguous with shape (win_height, win_width)
        self.win_weights = [
            np.ascontiguousarray(self._window_weight_fun(win_size, config.window_type))
            for win_size in config.window_sizes
        ]

        # Use precomputed cache if provided, otherwise compute it
        if precomputed_cache is not None:
            self._load_precomputed_cache(precomputed_cache)
        else:
            self._cache_window_padding(config=config)
            self.H, self.W = config.image_shape
            # Cache interpolation grids for performance
            self._cache_interpolation_grids(config=config)

        # Initialize vector masks (will be set in correlate_batch)
        self.vector_masks = []

        # Store pass times for profiling
        self.pass_times = []

    def _load_precomputed_cache(self, cache: dict) -> None:
        """Load precomputed cache data to avoid redundant computation.
        
        :param cache: Dictionary containing precomputed cache data
        :type cache: dict
        """
        # Load window padding cache
        self.win_ctrs_x = cache['win_ctrs_x']
        self.win_ctrs_y = cache['win_ctrs_y']
        self.win_spacing_x = cache['win_spacing_x']
        self.win_spacing_y = cache['win_spacing_y']
        self.win_ctrs_x_all = cache['win_ctrs_x_all']
        self.win_ctrs_y_all = cache['win_ctrs_y_all']
        self.n_pre_all = cache['n_pre_all']
        self.n_post_all = cache['n_post_all']
        self.ksize_filt = cache['ksize_filt']
        self.sd = cache['sd']
        self.G_smooth_predictor = cache['G_smooth_predictor']
        
        # Load image dimensions
        self.H = cache['H']
        self.W = cache['W']
        
        # Load interpolation grids cache
        self.im_mesh = cache['im_mesh']
        self.cached_dense_maps = cache['cached_dense_maps']
        self.cached_predictor_maps = cache['cached_predictor_maps']

    def get_cache_data(self) -> dict:
        """Extract cache data for sharing across workers.
        
        :return: Dictionary containing all cached data
        :rtype: dict
        """
        return {
            'win_ctrs_x': self.win_ctrs_x,
            'win_ctrs_y': self.win_ctrs_y,
            'win_spacing_x': self.win_spacing_x,
            'win_spacing_y': self.win_spacing_y,
            'win_ctrs_x_all': self.win_ctrs_x_all,
            'win_ctrs_y_all': self.win_ctrs_y_all,
            'n_pre_all': self.n_pre_all,
            'n_post_all': self.n_post_all,
            'ksize_filt': self.ksize_filt,
            'sd': self.sd,
            'G_smooth_predictor': self.G_smooth_predictor,
            'H': self.H,
            'W': self.W,
            'im_mesh': self.im_mesh,
            'cached_dense_maps': self.cached_dense_maps,
            'cached_predictor_maps': self.cached_predictor_maps,
        }

    
    def correlate_batch(  # type: ignore[override]
        self, images: np.ndarray, config: Config, vector_masks: List[np.ndarray] | None = None
    ) -> PIVResult:
        """Run PIV correlation on a batch of image pairs with MATLAB-style indexing."""

        # Validate input shape
        if images.ndim != 4:
            raise ValueError(f"Expected 4D images array (N, 2, H, W), got {images.ndim}D array with shape {images.shape}")

        N, C, H, W = images.shape

        # Validate channel dimension
        if C != 2:
            raise ValueError(f"Expected 2 channels (image pairs), got {C} channels")

        # Validate non-zero dimensions
        if H == 0 or W == 0:
            raise ValueError(f"Invalid image dimensions: H={H}, W={W}. Images appear to be empty.")

        # Log image batch info
        logging.debug(f"Processing batch: N={N} pairs, shape=({H}, {W}), dtype={images.dtype}")

        piv_result_all = PIVResult()
        self.delta_ab_pred = None
        self.delta_ab_old = None

        # Clear pass times for this batch
        self.pass_times = []

        # Use pre-computed vector masks
        self.vector_masks = vector_masks if vector_masks is not None else []

        y_coords = np.arange(self.H, dtype=np.float32)
        x_coords = np.arange(self.W, dtype=np.float32)
        y_mesh, x_mesh = np.meshgrid(y_coords, x_coords, indexing="ij")
        self.im_mesh = np.stack([y_mesh, x_mesh], axis=-1)

        for n in range(N):
            try:
                # Convert images to C-contiguous (row-major) format
                image_a = np.asarray(images[n, 0], dtype=np.float32)
                image_b = np.asarray(images[n, 1], dtype=np.float32)

                if not image_a.flags["C_CONTIGUOUS"]:
                    image_a = np.ascontiguousarray(image_a)
                if not image_b.flags["C_CONTIGUOUS"]:
                    image_b = np.ascontiguousarray(image_b)

                # Pass image_size as [H, W] in C-contiguous format
                image_size = np.ascontiguousarray(np.array([H, W], dtype=np.int32))

                for pass_idx, win_size in enumerate(config.window_sizes):
                    pass_start = time.perf_counter()
                    image_a_prime, image_b_prime, self.delta_ab_pred = (
                        self._predictor_corrector(
                            pass_idx,
                            image_a,
                            image_b,
                            win_type=config.window_type,
                        )
                    )

                    (
                        win_size_arr,
                        n_windows,
                        b_mask,
                        n_peaks,
                        i_peak_finder,
                        b_ensemble,
                        pk_loc_x,
                        pk_loc_y,
                        pk_height,
                        sx,
                        sy,
                        sxy,
                        correl_plane_out,
                    ) = self._set_lib_arguments(
                        config=config,
                        win_size=win_size,
                        pass_idx=pass_idx,
                    )
                    
                    # Ensure images are C-contiguous before passing to C library
                    image_a_prime_c = image_a_prime if image_a_prime.flags["C_CONTIGUOUS"] else np.ascontiguousarray(image_a_prime)
                    image_b_prime_c = image_b_prime if image_b_prime.flags["C_CONTIGUOUS"] else np.ascontiguousarray(image_b_prime)
                    
                    try:
                        error_code = self.lib.bulkxcorr2d(
                            image_a_prime_c,
                            image_b_prime_c,
                            b_mask,
                            image_size,
                            self.win_ctrs_x[pass_idx].astype(np.float32),
                            self.win_ctrs_y[pass_idx].astype(np.float32),
                            n_windows,
                            self.win_weights[pass_idx],
                            b_ensemble,
                            self.win_weights[pass_idx],
                            win_size_arr,
                            int(n_peaks),
                            int(i_peak_finder),
                            pk_loc_x,
                            pk_loc_y,
                            pk_height,
                            sx,
                            sy,
                            sxy,
                            correl_plane_out,
                        )
                    except Exception as e:
                        logging.error(f"    Exception type: {type(e).__name__}")
                        logging.error(traceback.format_exc())
                        raise

                    if error_code != 0:
                        error_names = {
                            1: "ERROR_NOMEM (out of memory)",
                            2: "ERROR_NOPLAN_FWD (FFT forward plan failed)",
                            4: "ERROR_NOPLAN_BWD (FFT backward plan failed)",
                            8: "ERROR_NOPLAN (general plan error)",
                            9: "ERROR_OUT_OF_BOUNDS (array access out of bounds)"
                        }
                        error_msg = error_names.get(error_code, f"Unknown error code {error_code}")
                        logging.error(f"    bulkxcorr2d returned error code {error_code}: {error_msg}")
                        raise RuntimeError(f"bulkxcorr2d failed with error {error_code}: {error_msg}")
                    
                    n_win_y = int(n_windows[0])
                    n_win_x = int(n_windows[1])
                    mask_bool = b_mask.astype(bool)

                    pk_loc_x[:, mask_bool] = np.nan
                    pk_loc_y[:, mask_bool] = np.nan
                    pk_height[:, mask_bool] = np.nan

                    win_height, win_width = win_size_arr.astype(np.int32)
                    large_disp_mask = (
                        (np.abs(pk_loc_x) > win_width / 4.0)
                        | (np.abs(pk_loc_y) > win_height / 4.0)
                    )
                    pk_loc_x[large_disp_mask] = np.nan
                    pk_loc_y[large_disp_mask] = np.nan
                    pk_height[large_disp_mask] = np.nan

                    # delta_ab_pred[..., 0] = Y-displacement, delta_ab_pred[..., 1] = X-displacement
                    # pk_loc_x is X-displacement, pk_loc_y is Y-displacement
                    pk_loc_x += self.delta_ab_pred[..., 1][np.newaxis, :, :]  # Add X-predictor to X
                    pk_loc_y += self.delta_ab_pred[..., 0][np.newaxis, :, :]  # Add Y-predictor to Y

                    primary_idx = np.zeros((1, n_win_y, n_win_x), dtype=np.intp)
                    ux_mat = np.take_along_axis(pk_loc_x, primary_idx, axis=0)[0]
                    uy_mat = np.take_along_axis(pk_loc_y, primary_idx, axis=0)[0]
                    # Use direct indexing without meshgrid for outlier detection and peak selection
                    n_win_y = int(n_windows[0])
                    n_win_x = int(n_windows[1])
                    peak_choice = np.ones((n_win_y, n_win_x), dtype=np.int32)

                    # Initial peak selection
                    ux_mat = pk_loc_x[0]
                    uy_mat = pk_loc_y[0]

                    nan_mask = np.isnan(ux_mat) | np.isnan(uy_mat)

                    # Include masked regions in nan_mask BEFORE outlier detection
                    # This ensures outlier detection excludes masked regions
                    nan_mask |= mask_bool

                    # Apply outlier detection if enabled
                    if config.outlier_detection_enabled:
                        outlier_methods = config.outlier_detection_methods
                        if outlier_methods:
                            # Get primary peak magnitude for peak_mag detection
                            primary_peak_mag_temp = pk_height[0]
                            outlier_mask = apply_outlier_detection(
                                ux_mat, uy_mat, outlier_methods, peak_mag=primary_peak_mag_temp
                            )
                            nan_mask |= outlier_mask

                    if config.secondary_peak:
                        for pk in range(1, n_peaks):
                            # Increment peak_choice for nan_mask locations
                            peak_choice[nan_mask] += 1
                            # Clamp peak_choice to valid range
                            peak_choice = np.clip(peak_choice, 1, n_peaks)
                            # Select new peak for nan_mask locations
                            ux_mat = np.choose(peak_choice - 1, pk_loc_x)
                            uy_mat = np.choose(peak_choice - 1, pk_loc_y)
                            if config.outlier_detection_enabled:
                                outlier_methods = config.outlier_detection_methods
                                if outlier_methods:
                                    primary_peak_mag_temp = np.choose(peak_choice - 1, pk_height)
                                    outlier_mask = apply_outlier_detection(
                                        ux_mat, uy_mat, outlier_methods, peak_mag=primary_peak_mag_temp
                                    )
                                    nan_mask |= outlier_mask
                            if not nan_mask.any():
                                break

                    # Select primary peak magnitude
                    primary_peak_mag = np.choose(peak_choice - 1, pk_height)
                    nan_mask |= np.isnan(primary_peak_mag)

                    # Q calculation (peak ratio)
                    shifted_pk_height = np.roll(pk_height, shift=-1, axis=0)
                    shifted_pk_height[-1, :, :] = pk_height[-1, :, :]
                    with warnings.catch_warnings():
                        warnings.simplefilter("ignore", category=RuntimeWarning)
                        Q_mat = np.divide(
                            pk_height,
                            shifted_pk_height,
                            out=np.zeros_like(pk_height),
                            where=shifted_pk_height > 0,
                        )

                    Q = np.choose(peak_choice - 1, Q_mat)

                    if nan_mask.any():
                        ux_mat[nan_mask] = np.nan
                        uy_mat[nan_mask] = np.nan
                        primary_peak_mag[nan_mask] = np.nan
                        Q[nan_mask] = 0.0

                    ux_mat[mask_bool] = 0.0
                    uy_mat[mask_bool] = 0.0

                    # Apply infilling for mid-passes or final pass
                    is_final_pass = (pass_idx == len(config.window_sizes) - 1)
                    
                    if is_final_pass:
                        # Final pass infilling (optional)
                        final_infill_cfg = config.infilling_final_pass
                        if final_infill_cfg.get('enabled', True) and np.isnan(ux_mat).any():
                            infill_mask = np.isnan(ux_mat) | np.isnan(uy_mat)
                            ux_mat, uy_mat = apply_infilling(
                                ux_mat, uy_mat, infill_mask, final_infill_cfg
                            )
                    else:
                        # Mid-pass infilling (required for predictor)
                        if np.isnan(ux_mat).any() or np.isnan(uy_mat).any():
                            infill_mask = np.isnan(ux_mat) | np.isnan(uy_mat)
                            mid_infill_cfg = config.infilling_mid_pass
                            ux_mat, uy_mat = apply_infilling(
                                ux_mat, uy_mat, infill_mask, mid_infill_cfg
                            )

                    ux_mat[mask_bool] = 0.0
                    uy_mat[mask_bool] = 0.0
                    peak_choice[nan_mask] = 0

                    ux_mat = np.ascontiguousarray(ux_mat.astype(np.float32))
                    uy_mat = np.ascontiguousarray(uy_mat.astype(np.float32))
                    nan_mask = np.ascontiguousarray(nan_mask)
                    Q = np.ascontiguousarray(Q.astype(np.float32))
                    primary_peak_mag = np.ascontiguousarray(
                        np.where(nan_mask, 0.0, primary_peak_mag.astype(np.float32))
                    )
                    pk_height = np.ascontiguousarray(pk_height.astype(np.float32))

                    # Stack as [Y, X] to match im_mesh structure where [..., 0] = Y and [..., 1] = X
                    # This ensures correct image warping: im_mesh + delta_ab aligns Y with Y and X with X
                    self.delta_ab_old = np.stack([uy_mat, ux_mat], axis=2)
                    pre_y, pre_x = self.n_pre_all[pass_idx]
                    post_y, post_x = self.n_post_all[pass_idx]
                    self.delta_ab_old = np.pad(
                        self.delta_ab_old,
                        ((pre_y, post_y), (pre_x, post_x), (0, 0)),
                        mode="edge",
                    )

                    self.previous_win_spacing = (
                        self.win_spacing_y[pass_idx],
                        self.win_spacing_x[pass_idx],
                    )
                    self.prev_win_size = (n_win_y, n_win_x)

                    pass_result = PIVPassResult(
                        n_windows=np.array([n_win_y, n_win_x], dtype=np.int32),
                        ux_mat=np.copy(ux_mat),
                        uy_mat=np.copy(uy_mat),
                        nan_mask=np.copy(nan_mask),
                        peak_mag=np.copy(pk_height),
                        peak_choice=np.copy(peak_choice),
                        predictor_field=np.copy(self.delta_ab_old),
                        b_mask=b_mask.reshape((n_win_y, n_win_x)).astype(bool),
                        window_size=win_size,
                        win_ctrs_x=self.win_ctrs_x[pass_idx],
                        win_ctrs_y=self.win_ctrs_y[pass_idx],

                    )
                    pass_time = time.perf_counter() - pass_start
                    self.pass_times.append((n, pass_idx, pass_time))
                    piv_result_all.add_pass(pass_result)
                    
                    # Explicit memory cleanup to prevent accumulation
                    # These large intermediate arrays can consume 500+ MB per pass
                    del pk_loc_x, pk_loc_y, pk_height, correl_plane_out
                    del image_a_prime, image_b_prime
                    del sx, sy, sxy, Q_mat
                    # Force garbage collection after last pass to release memory
                    if pass_idx == len(config.window_sizes) - 1:
                        import gc
                        gc.collect()

            except Exception as exc:
                logging.error("Error in correlate_batch for image %d: %s", n, exc)
                logging.error(traceback.format_exc())
                raise

        return piv_result_all

    def _compute_window_centres(
        self, pass_idx: int, config: Config
    ) -> tuple[int, int, np.ndarray, np.ndarray]:
        """
        Compute window centers and spacing for a given pass using centralized utilities.

        Uses pivtools_core.window_utils.compute_window_centers() for consistency
        across all PIV modes (instantaneous, ensemble, masking).

        :param pass_idx: Index of the current pass.
        :type pass_idx: int
        :param config: Configuration object containing window sizes, overlap, and image shape.
        :type config: Config
        :return: Tuple containing window spacing in x and y, and arrays of window center coordinates in x and y.
        :rtype: tuple[int, int, np.ndarray, np.ndarray]
        """
        win_height, win_width = config.window_sizes[pass_idx]
        overlap = config.overlap[pass_idx]

        logging.debug(f"_compute_window_centres pass {pass_idx}:")
        logging.debug(f"  Image shape (H, W) = {config.image_shape}")
        logging.debug(f"  Window size (H, W) = ({win_height}, {win_width})")
        logging.debug(f"  Overlap = {overlap}%")

        # Use centralized window center computation
        result = compute_window_centers(
            image_shape=config.image_shape,
            window_size=(win_height, win_width),
            overlap=overlap,
            validate=True
        )

        logging.debug(f"  Window spacing (X, Y) = ({result.win_spacing_x}, {result.win_spacing_y})")
        logging.debug(f"  Number of windows (X, Y) = ({result.n_win_x}, {result.n_win_y})")

        if len(result.win_ctrs_x) > 0:
            logging.debug(
                f"  win_ctrs_x: min={result.win_ctrs_x.min():.2f}, "
                f"max={result.win_ctrs_x.max():.2f}, len={len(result.win_ctrs_x)}"
            )
        else:
            logging.warning(f"  win_ctrs_x: EMPTY ARRAY (len=0)")

        if len(result.win_ctrs_y) > 0:
            logging.debug(
                f"  win_ctrs_y: min={result.win_ctrs_y.min():.2f}, "
                f"max={result.win_ctrs_y.max():.2f}, len={len(result.win_ctrs_y)}"
            )
        else:
            logging.warning(f"  win_ctrs_y: EMPTY ARRAY (len=0)")

        return (
            result.win_spacing_x,
            result.win_spacing_y,
            np.ascontiguousarray(result.win_ctrs_x),
            np.ascontiguousarray(result.win_ctrs_y),
        )

    def _check_args(self, *args):
        """Check the arguments for consistency and validity if debug mode is enabled.
        Parameters
        ----------
        *args : list of tuples
            Each tuple contains (name, array) to be checked.

        """

        def _describe(arr):
            if isinstance(arr, np.ndarray):
                return (arr.shape, arr.dtype, arr.flags["C_CONTIGUOUS"])
            return (type(arr), arr)

        for name, arr in args:
            logging.info(f"{name}: {_describe(arr)}")
    
    def _predictor_corrector(
        self,
        pass_idx: int,
        image_a: np.ndarray,
        image_b: np.ndarray,
        interpolator="cubic",
        win_type="A",
    ):
        """Predictor-corrector step to adjust images based on previous displacement estimates."""

        n_win_y = len(self.win_ctrs_y[pass_idx])
        n_win_x = len(self.win_ctrs_x[pass_idx])
        self.delta_ab_pred = np.zeros((n_win_y, n_win_x, 2), dtype=np.float32)

        if pass_idx == 0:
            if self.delta_ab_old is None:
                self.delta_ab_old = np.zeros_like(self.delta_ab_pred)

            self.prev_win_size = (n_win_y, n_win_x)
            self.prev_win_spacing = (
                self.win_spacing_y[pass_idx],
                self.win_spacing_x[pass_idx],
            )
            return image_a.copy(), image_b.copy(), self.delta_ab_pred

        if self.delta_ab_old is None:
            raise RuntimeError("delta_ab_old is uninitialised before predictor step")

        interp_flag = cv2.INTER_CUBIC if interpolator == "cubic" else cv2.INTER_LINEAR

        self.delta_ab_old[..., 0] = gaussian_filter(
            self.delta_ab_old[..., 0],
            sigma=self.sd[pass_idx],
            truncate=(self.ksize_filt[pass_idx][0] - 1) / (2 * self.sd[pass_idx]),
            mode="nearest",
        )
        self.delta_ab_old[..., 1] = gaussian_filter(
            self.delta_ab_old[..., 1],
            sigma=self.sd[pass_idx],
            truncate=(self.ksize_filt[pass_idx][0] - 1) / (2 * self.sd[pass_idx]),
            mode="nearest",
        )

        self.delta_ab_dense = np.zeros((self.H, self.W, 2), dtype=np.float32)
        map_x_2d, map_y_2d = self.cached_dense_maps[pass_idx]
        if map_x_2d is None or map_y_2d is None:
            raise ValueError(f"Dense interpolation maps missing for pass {pass_idx}")
        
        # Verify cached dense maps have correct shape
        assert map_x_2d.shape == (self.H, self.W), f"Cached dense map X shape mismatch for pass {pass_idx}: {map_x_2d.shape} vs {(self.H, self.W)}"
        assert map_y_2d.shape == (self.H, self.W), f"Cached dense map Y shape mismatch for pass {pass_idx}: {map_y_2d.shape} vs {(self.H, self.W)}"
        logging.debug(f"Using cached dense interpolation maps for pass {pass_idx}")

        for d in range(2):
            self.delta_ab_dense[..., d] = cv2.remap(
                self.delta_ab_old[..., d].astype(np.float32),
                map_x_2d,
                map_y_2d,
                interp_flag,
                borderMode=cv2.BORDER_CONSTANT,
                borderValue=0,
            )

        delta_0b = self.delta_ab_dense / 2
        delta_0a = -delta_0b
        im_mesh_A = self.im_mesh + delta_0a
        im_mesh_B = self.im_mesh + delta_0b

        map_x, map_y = self.cached_predictor_maps[pass_idx]
        if map_x is None or map_y is None:
            raise ValueError(f"Predictor interpolation maps missing for pass {pass_idx}")
        
        # Verify cached predictor maps have correct shape
        expected_pred_shape = (len(self.win_ctrs_y[pass_idx]), len(self.win_ctrs_x[pass_idx]))
        assert map_x.shape == expected_pred_shape, f"Cached predictor map X shape mismatch for pass {pass_idx}: {map_x.shape} vs {expected_pred_shape}"
        assert map_y.shape == expected_pred_shape, f"Cached predictor map Y shape mismatch for pass {pass_idx}: {map_y.shape} vs {expected_pred_shape}"
        logging.debug(f"Using cached predictor interpolation maps for pass {pass_idx}")

        for d in range(2):
            remapped = cv2.remap(
                self.delta_ab_old[..., d].astype(np.float32),
                map_x,
                map_y,
                interp_flag,
                borderMode=cv2.BORDER_CONSTANT,
                borderValue=0.0,
            )
            self.delta_ab_pred[..., d] = remapped

        image_a_prime = cv2.remap(
            image_a.astype(np.float32),
            im_mesh_A[..., 1].astype(np.float32),
            im_mesh_A[..., 0].astype(np.float32),
            cv2.INTER_CUBIC,
            borderMode=cv2.BORDER_CONSTANT,
            borderValue=0,
        )
        image_b_prime = cv2.remap(
            image_b.astype(np.float32),
            im_mesh_B[..., 1].astype(np.float32),
            im_mesh_B[..., 0].astype(np.float32),
            cv2.INTER_CUBIC,
            borderMode=cv2.BORDER_CONSTANT,
            borderValue=0,
        )

        return image_a_prime, image_b_prime, self.delta_ab_pred
    
    def _set_lib_arguments(
        self,
        config: Config,
        win_size: np.ndarray,
        pass_idx: int,
    ):
        """Set library arguments for PIV computation.

        :param config: Configuration object.
        :type config: Config
        :param win_size: Window size.
        :type win_size: np.ndarray
        :param pass_idx: Pass index.
        :type pass_idx: int
        :return: Tuple of library arguments.
        :rtype: tuple
        """
        # Window size: [win_height, win_width] in C-contiguous format
        win_size = np.ascontiguousarray(np.array(win_size, dtype=np.int32))

        n_win_y = len(self.win_ctrs_y[pass_idx])
        n_win_x = len(self.win_ctrs_x[pass_idx])
        # nWindows: [n_win_y, n_win_x] where n_win_y = rows, n_win_x = cols
        n_windows = np.ascontiguousarray(
            np.array([n_win_y, n_win_x], dtype=np.int32)
        )

        total_windows = n_win_y * n_win_x

        # Use precomputed vector mask for this pass if available
        # Mask shape: (n_win_y, n_win_x) in C-contiguous format
        if hasattr(self, 'vector_masks') and self.vector_masks and pass_idx < len(self.vector_masks):
            cached_mask = self.vector_masks[pass_idx]
            b_mask = np.ascontiguousarray(cached_mask.astype(np.float32))
        else:
            b_mask = np.ascontiguousarray(np.zeros((n_win_y, n_win_x), dtype=np.float32))
            logging.debug("No vector mask applied for pass %d", pass_idx)

        n_peaks = np.int32(config.num_peaks)
        i_peak_finder = np.int32(config.peak_finder)
        b_ensemble = bool(config.ensemble_piv)

        # Output arrays shape: (n_peaks, n_win_y, n_win_x) in C-contiguous format
        out_shape = (n_peaks, n_win_y, n_win_x)
        pk_loc_x = np.zeros(out_shape, dtype=np.float32)
        pk_loc_y = np.zeros(out_shape, dtype=np.float32)
        pk_height = np.zeros(out_shape, dtype=np.float32)
        sx = np.zeros(out_shape, dtype=np.float32)
        sy = np.zeros(out_shape, dtype=np.float32)
        sxy = np.zeros(out_shape, dtype=np.float32)

        # Correlation plane output: flattened array (not used, so use empty to save memory)
        correl_plane_out = np.empty(total_windows * win_size[0] * win_size[1], dtype=np.float32)

        if config.debug:
            args = [
                ("mask", b_mask),
                ("win_ctrs_x", self.win_ctrs_x[pass_idx].astype(np.float32)),
                ("win_ctrs_y", self.win_ctrs_y[pass_idx].astype(np.float32)),
                ("n_windows", n_windows),
                ("window_weight_a", self.win_weights[pass_idx]),
                ("b_ensemble", b_ensemble),
                ("window_weight_b", self.win_weights[pass_idx]),
                ("win_size", win_size),
                ("n_peaks", int(n_peaks)),
                ("i_peak_finder", int(i_peak_finder)),
                ("pk_loc_x", pk_loc_x),
                ("pk_loc_y", pk_loc_y),
                ("pk_height", pk_height),
                ("sx", sx),
                ("sy", sy),
                ("sxy", sxy),
                ("correl_plane_out", correl_plane_out),
            ]
            self._check_args(*args)

        return (
            win_size,
            n_windows,
            b_mask,
            n_peaks,
            i_peak_finder,
            b_ensemble,
            pk_loc_x,
            pk_loc_y,
            pk_height,
            sx,
            sy,
            sxy,
            correl_plane_out,
        )

    
    def _cache_window_padding(self, config: Config) -> None:
        """Cache window padding information.

        Uses unified base class implementation with instantaneous-specific parameters.
        """
        self._cache_window_padding_unified(
            config=config,
            window_sizes=config.window_sizes,
            window_type=config.window_type,
            compute_window_fn=self._compute_window_centres,
            first_pass_ksize=(0, 0),  # Instantaneous uses (0, 0) for first pass
        )

    
    
    def _cache_interpolation_grids(self, config: Config) -> None:
        """Cache interpolation grid coordinates for reuse across passes.

        Uses unified base class implementation with instantaneous-specific parameters.
        """
        self._cache_interpolation_grids_unified(
            config=config,
            window_sizes=config.window_sizes,
            include_first_pass=False,  # Instantaneous doesn't need first pass grids
        )

        # Verify caching integrity (keep assertions for debugging)
        assert len(self.cached_dense_maps) == len(config.window_sizes), \
            f"Dense maps cache length mismatch: {len(self.cached_dense_maps)} vs {len(config.window_sizes)}"
        assert len(self.cached_predictor_maps) == len(config.window_sizes), \
            f"Predictor maps cache length mismatch: {len(self.cached_predictor_maps)} vs {len(config.window_sizes)}"

        for pass_idx in range(1, len(config.window_sizes)):
            assert self.cached_dense_maps[pass_idx] is not None, \
                f"Dense map for pass {pass_idx} is None"
            assert self.cached_predictor_maps[pass_idx] is not None, \
                f"Predictor map for pass {pass_idx} is None"
